"""
Vertragsübersicht – Verträge ansehen, neu anlegen und bearbeiten

Eine durchsuchbare Liste aller Verträge. Per Doppelklick (oder Button
"Bearbeiten") öffnet sich der Vertrag im selben Formular wie beim Erfassen,
mit denselben Prüfungen. Beim Speichern wird der Vertrag in der Datenbank
aktualisiert (UPDATE), danach zeigt die Liste den neuen Stand.

Benötigt vertrag_erfassen.py und vertragsverwaltung_gui.py im selben Ordner.
"""

import tkinter as tk
from tkinter import messagebox, ttk

import customtkinter as ctk

from vertrag_erfassen import (
    AKZENT, AKZENT_HOVER, EINGABE_HG, EINGABE_RAND, ERFOLG, FEHLER, HINTERGRUND, KARTE, KARTE_RAND,
    INTERVALL_ANZEIGE, SEGMENT_HG, SEGMENT_HOVER, STATUS_ANZEIGE, TEXT, TEXT_LEISE, VertragBearbeiten,
    VertragUnterfenster,
)
from vertragsverwaltung_gui import (
    DB_CONFIG, DB_TYPE, Datenbankverbindung, VertragRepository, dbapi, formatiere_betrag,
)


ALLE_STATUS = "Alle Status"
STATUS_TEXT = {wert: text for text, wert in STATUS_ANZEIGE.items()}
INTERVALL_TEXT = {wert: text for text, wert in INTERVALL_ANZEIGE.items()}

# (Spalte, Überschrift, Breite)
SPALTEN = (
    ("nummer", "Nummer", 95),
    ("titel", "Titel", 160),
    ("partner", "Vertragspartner", 140),
    ("art", "Vertragsart", 100),
    ("verantwortlich", "Verantwortlich", 115),
    ("abteilung", "Abteilung", 85),
    ("laufzeit", "Monate", 70),
    ("beginn", "Beginn", 80),
    ("ende", "Ende", 80),
    ("kosten", "Kosten", 165),
    ("status", "Status", 80),
)


def tabellenzeile(v: dict) -> dict:
    """Vertrag aus der Datenbank -> Texte für die Spalten der Tabelle."""
    kosten = ""
    if v["kosten"] is not None:
        kosten = f"{formatiere_betrag(v['kosten'])} €"
        if v["zahlungsintervall"]:
            kosten += f" ({INTERVALL_TEXT.get(v['zahlungsintervall'], v['zahlungsintervall'])})"
    return {
        "nummer": v["vertragsnummer"],
        "titel": v["titel"],
        "partner": v["firmenname"],
        "art": v["vertragsart"],
        "verantwortlich": f"{v['vorname']} {v['nachname']}",
        "abteilung": v["abteilung"],
        "laufzeit": v["laufzeit"],
        "beginn": f"{v['beginn_datum']:%d.%m.%Y}",
        "ende": f"{v['end_datum']:%d.%m.%Y}" if v["end_datum"] else "unbefristet",
        "kosten": kosten,
        "status": STATUS_TEXT.get(v["status"], v["status"]),
    }


def passt_zum_filter(zeile: dict, suche: str, status: str) -> bool:
    if status != ALLE_STATUS and zeile["status"] != status:
        return False
    return all(wort in " ".join(zeile.values()).lower() for wort in suche.lower().split())


class VertragsUebersicht(ctk.CTk):
    def __init__(self, db: Datenbankverbindung):
        super().__init__()
        self.db = db
        self.repo = VertragRepository(db)
        self.vertraege = []
        self.bearbeiten_fenster = None

        self.title("Vertragsübersicht")
        self.geometry("1280x720")
        self.minsize(820, 480)
        self.configure(fg_color=HINTERGRUND)
        self.protocol("WM_DELETE_WINDOW", self.beenden)

        self.schrift_titel = ctk.CTkFont(size=24, weight="bold")
        self.schrift_feld = ctk.CTkFont(size=13, weight="bold")
        self.schrift_normal = ctk.CTkFont(size=13)

        self._baue_kopfzeile()
        self._baue_fusszeile()
        self._baue_tabelle()
        self.neu_laden()

    # ---------- Aufbau ----------

    def _baue_kopfzeile(self):
        kopf = ctk.CTkFrame(self, fg_color=KARTE, corner_radius=0)
        kopf.pack(fill="x")
        ctk.CTkLabel(kopf, text="Vertragsübersicht", font=self.schrift_titel, text_color=TEXT,
                     anchor="w").pack(fill="x", padx=32, pady=(18, 0))
        ctk.CTkLabel(kopf, text="Doppelklick auf einen Vertrag öffnet ihn zum Bearbeiten.",
                     font=self.schrift_normal, text_color=TEXT_LEISE,
                     anchor="w").pack(fill="x", padx=32)

        filter_zeile = ctk.CTkFrame(kopf, fg_color="transparent")
        filter_zeile.pack(fill="x", padx=32, pady=(12, 18))
        self.suche = ctk.CTkEntry(filter_zeile, placeholder_text="Suchen: Nummer, Titel, Partner …",
                                  height=36, width=340, corner_radius=8, border_width=1,
                                  border_color=EINGABE_RAND, fg_color=EINGABE_HG, text_color=TEXT,
                                  font=self.schrift_normal)
        self.suche.pack(side="left")
        self.suche.bind("<KeyRelease>", lambda _e: self.zeige_vertraege())

        self.status_filter = ctk.CTkOptionMenu(filter_zeile, values=[ALLE_STATUS, *STATUS_ANZEIGE],
                                               height=36, width=150, corner_radius=8,
                                               fg_color=SEGMENT_HG, button_color=SEGMENT_HG,
                                               button_hover_color=SEGMENT_HOVER, text_color=TEXT,
                                               dropdown_fg_color=KARTE, dropdown_text_color=TEXT,
                                               dropdown_hover_color=SEGMENT_HG, font=self.schrift_normal,
                                               command=lambda _w: self.zeige_vertraege())
        self.status_filter.pack(side="left", padx=(10, 0))

        ctk.CTkButton(filter_zeile, text="Liste neu laden", command=self.neu_laden, height=36, width=130,
                      corner_radius=8, font=self.schrift_normal, fg_color="transparent",
                      border_width=1, border_color=EINGABE_RAND, text_color=TEXT,
                      hover_color=KARTE_RAND).pack(side="right")

    def _baue_fusszeile(self):
        fuss = ctk.CTkFrame(self, fg_color=KARTE, corner_radius=0)
        fuss.pack(side="bottom", fill="x")
        self.status = ctk.CTkLabel(fuss, text="", font=self.schrift_normal, text_color=TEXT_LEISE,
                                   anchor="w", justify="left")
        self.status.pack(side="left", padx=32, fill="x", expand=True)
        ctk.CTkButton(fuss, text="Bearbeiten", command=self.bearbeiten, height=42, width=160,
                      corner_radius=10, font=self.schrift_feld, fg_color=AKZENT,
                      hover_color=AKZENT_HOVER).pack(side="right", padx=(8, 32), pady=15)
        ctk.CTkButton(fuss, text="Neuer Vertrag", command=self.neuer_vertrag, height=42, width=160,
                      corner_radius=10, font=self.schrift_feld, fg_color="transparent",
                      border_width=1, border_color=AKZENT, text_color=AKZENT,
                      hover_color=KARTE_RAND).pack(side="right", pady=15)

    def _baue_tabelle(self):
        stil = ttk.Style(self)
        stil.theme_use("clam")
        hell = lambda farbe: farbe[0]
        stil.configure("Vertraege.Treeview", background=hell(KARTE), fieldbackground=hell(KARTE),
                       foreground=hell(TEXT), rowheight=32, borderwidth=0, font=("Segoe UI", 10))
        stil.configure("Vertraege.Treeview.Heading", background=hell(SEGMENT_HG), foreground=hell(TEXT),
                       relief="flat", padding=6, font=("Segoe UI", 10, "bold"))
        stil.map("Vertraege.Treeview", background=[("selected", hell(AKZENT))],
                 foreground=[("selected", "#ffffff")])
        stil.map("Vertraege.Treeview.Heading", background=[("active", hell(SEGMENT_HOVER))])

        rahmen = ctk.CTkFrame(self, fg_color=KARTE, corner_radius=14, border_width=1,
                              border_color=KARTE_RAND)
        rahmen.pack(fill="both", expand=True, padx=24, pady=16)

        self.tabelle = ttk.Treeview(rahmen, columns=[s[0] for s in SPALTEN], show="headings",
                                    style="Vertraege.Treeview", selectmode="browse")
        for name, ueberschrift, breite in SPALTEN:
            self.tabelle.heading(name, text=ueberschrift, anchor="w")
            self.tabelle.column(name, width=breite, minwidth=50, anchor="w", stretch=name == "titel")
        scroll = ctk.CTkScrollbar(rahmen, command=self.tabelle.yview)
        scroll_quer = ctk.CTkScrollbar(rahmen, orientation="horizontal", command=self.tabelle.xview)
        self.tabelle.configure(yscrollcommand=scroll.set, xscrollcommand=scroll_quer.set)
        scroll_quer.pack(side="bottom", fill="x", padx=(8, 6), pady=(0, 6))
        scroll.pack(side="right", fill="y", padx=(0, 6), pady=(8, 0))
        self.tabelle.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=(8, 0))

        self.leer_hinweis = ctk.CTkLabel(rahmen, text="", font=self.schrift_normal, text_color=TEXT_LEISE,
                                         fg_color=KARTE)

        self.tabelle.bind("<Double-1>", self._doppelklick)
        self.tabelle.bind("<Return>", lambda _e: self.bearbeiten())

    # ---------- Daten ----------

    def neu_laden(self):
        try:
            self.vertraege = self.repo.finde_alle()
        except dbapi.Error as fehler:
            messagebox.showerror("Datenbankfehler", f"Die Verträge konnten nicht geladen werden:\n\n{fehler}")
            return
        self.zeige_vertraege()

    def zeige_vertraege(self):
        gewaehlt = self.tabelle.selection()
        suche = self.suche.get().strip()
        status = self.status_filter.get()
        self.tabelle.delete(*self.tabelle.get_children())

        anzahl = 0
        for vertrag in self.vertraege:
            zeile = tabellenzeile(vertrag)
            if passt_zum_filter(zeile, suche, status):
                self.tabelle.insert("", "end", iid=str(vertrag["id_vertrag"]),
                                    values=[zeile[s[0]] for s in SPALTEN])
                anzahl += 1
        if gewaehlt and self.tabelle.exists(gewaehlt[0]):
            self.tabelle.selection_set(gewaehlt[0])

        if anzahl:
            self.leer_hinweis.place_forget()
        else:
            self.leer_hinweis.configure(text="Keine passenden Verträge gefunden." if self.vertraege
                                        else "Es sind noch keine Verträge gespeichert.")
            self.leer_hinweis.place(relx=0.5, rely=0.5, anchor="center")
        self.status.configure(text=f"{anzahl} von {len(self.vertraege)} Verträgen", text_color=TEXT_LEISE)

    # ---------- Neu anlegen und bearbeiten ----------

    def _doppelklick(self, event):
        if self.tabelle.identify_row(event.y):
            self.bearbeiten()

    def _fenster_schon_offen(self) -> bool:
        if self.bearbeiten_fenster is None or not self.bearbeiten_fenster.winfo_exists():
            return False
        self.status.configure(text="Bitte zuerst das offene Vertragsfenster schließen.", text_color=FEHLER)
        self.bearbeiten_fenster.lift()
        self.bearbeiten_fenster.focus_force()
        return True

    def neuer_vertrag(self):
        if self._fenster_schon_offen():
            return
        try:
            self.bearbeiten_fenster = VertragUnterfenster(self.db, self._gespeichert)
        except dbapi.Error as fehler:
            messagebox.showerror("Datenbankfehler", str(fehler))

    def bearbeiten(self):
        auswahl = self.tabelle.selection()
        if not auswahl:
            self.status.configure(text="Bitte zuerst einen Vertrag in der Liste auswählen.", text_color=FEHLER)
            return
        if self._fenster_schon_offen():
            return
        try:
            daten = self.repo.finde_nach_id(int(auswahl[0]))     # immer der aktuelle Stand
            if daten is None:
                messagebox.showwarning("Nicht gefunden", "Diesen Vertrag gibt es nicht mehr.")
                self.neu_laden()
                return
            self.bearbeiten_fenster = VertragBearbeiten(self.db, daten, self._gespeichert)
        except dbapi.Error as fehler:
            messagebox.showerror("Datenbankfehler", str(fehler))

    def _gespeichert(self, id_vertrag: int, zusammenfassung: str):
        self.neu_laden()
        if self.tabelle.exists(str(id_vertrag)):
            self.tabelle.selection_set(str(id_vertrag))
            self.tabelle.see(str(id_vertrag))
        self.status.configure(text=zusammenfassung, text_color=ERFOLG)

    def beenden(self):
        self.db.trennen()
        self.destroy()


# =====================================================
# START
# =====================================================

def main():
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")
    db = Datenbankverbindung(DB_CONFIG, DB_TYPE)
    try:
        db.verbinden()
    except dbapi.Error as fehler:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Verbindung fehlgeschlagen",
                             f"Keine Verbindung zur Datenbank möglich:\n\n{fehler}\n\n"
                             "Bitte die Einstellungen in vertragsverwaltung_gui.py prüfen.")
        root.destroy()
        return
    VertragsUebersicht(db).mainloop()


if __name__ == "__main__":
    main()
